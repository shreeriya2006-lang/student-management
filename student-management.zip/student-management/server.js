const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, "data", "students.json");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// ---------- helpers (simple JSON-file "database") ----------
const readStudents = () => {
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
  } catch {
    return [];
  }
};
const writeStudents = (list) =>
  fs.writeFileSync(DB_FILE, JSON.stringify(list, null, 2));

const validate = (b) => {
  const errors = [];
  if (!b.name || !String(b.name).trim()) errors.push("name is required");
  if (!b.email || !/^\S+@\S+\.\S+$/.test(b.email)) errors.push("valid email is required");
  if (!b.course || !String(b.course).trim()) errors.push("course is required");
  const age = Number(b.age);
  if (!Number.isInteger(age) || age < 3 || age > 100) errors.push("age must be a number between 3 and 100");
  return errors;
};

// ---------- REST API ----------
// GET all (optional ?search=)
app.get("/api/students", (req, res) => {
  let list = readStudents();
  const q = (req.query.search || "").toLowerCase();
  if (q) {
    list = list.filter((s) =>
      [s.name, s.email, s.course].some((v) => v.toLowerCase().includes(q))
    );
  }
  res.json(list);
});

// GET one
app.get("/api/students/:id", (req, res) => {
  const s = readStudents().find((x) => x.id === Number(req.params.id));
  if (!s) return res.status(404).json({ message: "Student not found" });
  res.json(s);
});

// CREATE
app.post("/api/students", (req, res) => {
  const errors = validate(req.body);
  if (errors.length) return res.status(400).json({ errors });

  const list = readStudents();
  if (list.some((s) => s.email.toLowerCase() === req.body.email.toLowerCase()))
    return res.status(409).json({ errors: ["email already exists"] });

  const student = {
    id: list.length ? Math.max(...list.map((s) => s.id)) + 1 : 1,
    name: req.body.name.trim(),
    email: req.body.email.trim(),
    course: req.body.course.trim(),
    age: Number(req.body.age),
  };
  list.push(student);
  writeStudents(list);
  res.status(201).json(student);
});

// UPDATE
app.put("/api/students/:id", (req, res) => {
  const errors = validate(req.body);
  if (errors.length) return res.status(400).json({ errors });

  const list = readStudents();
  const idx = list.findIndex((s) => s.id === Number(req.params.id));
  if (idx === -1) return res.status(404).json({ message: "Student not found" });

  if (list.some((s, i) => i !== idx && s.email.toLowerCase() === req.body.email.toLowerCase()))
    return res.status(409).json({ errors: ["email already exists"] });

  list[idx] = {
    ...list[idx],
    name: req.body.name.trim(),
    email: req.body.email.trim(),
    course: req.body.course.trim(),
    age: Number(req.body.age),
  };
  writeStudents(list);
  res.json(list[idx]);
});

// DELETE
app.delete("/api/students/:id", (req, res) => {
  const list = readStudents();
  const idx = list.findIndex((s) => s.id === Number(req.params.id));
  if (idx === -1) return res.status(404).json({ message: "Student not found" });
  const [removed] = list.splice(idx, 1);
  writeStudents(list);
  res.json({ message: "Deleted", student: removed });
});

app.listen(PORT, () =>
  console.log(`Server running at http://localhost:${PORT}`)
);
