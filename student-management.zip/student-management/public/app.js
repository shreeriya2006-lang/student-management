const API = "/api/students";
const $ = (id) => document.getElementById(id);

const form = $("studentForm");
const tbody = $("tbody");
let searchTimer;

function showMessage(text, type = "ok") {
  const m = $("message");
  m.textContent = text;
  m.className = "message " + type;
  if (text) setTimeout(() => (m.textContent = ""), 3500);
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

async function loadStudents() {
  const q = $("search").value.trim();
  const res = await fetch(`${API}?search=${encodeURIComponent(q)}`);
  const students = await res.json();

  $("count").textContent = students.length;
  $("empty").hidden = students.length > 0;
  tbody.innerHTML = students
    .map(
      (s) => `
    <tr>
      <td>${s.id}</td>
      <td>${escapeHtml(s.name)}</td>
      <td>${escapeHtml(s.email)}</td>
      <td>${escapeHtml(s.course)}</td>
      <td>${s.age}</td>
      <td class="btns">
        <button class="small" onclick="editStudent(${s.id})">Edit</button>
        <button class="small danger" onclick="deleteStudent(${s.id})">Delete</button>
      </td>
    </tr>`
    )
    .join("");
}

function resetForm() {
  form.reset();
  $("studentId").value = "";
  $("formTitle").textContent = "Add Student";
  $("saveBtn").textContent = "Add Student";
  $("cancelBtn").hidden = true;
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = $("studentId").value;
  const body = {
    name: $("name").value,
    email: $("email").value,
    course: $("course").value,
    age: $("age").value,
  };

  const res = await fetch(id ? `${API}/${id}` : API, {
    method: id ? "PUT" : "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json();

  if (!res.ok) {
    return showMessage((data.errors || [data.message]).join(", "), "error");
  }
  showMessage(id ? "Student updated ✔" : "Student added ✔");
  resetForm();
  loadStudents();
});

window.editStudent = async (id) => {
  const res = await fetch(`${API}/${id}`);
  const s = await res.json();
  $("studentId").value = s.id;
  $("name").value = s.name;
  $("email").value = s.email;
  $("course").value = s.course;
  $("age").value = s.age;
  $("formTitle").textContent = `Edit Student #${s.id}`;
  $("saveBtn").textContent = "Update Student";
  $("cancelBtn").hidden = false;
  window.scrollTo({ top: 0, behavior: "smooth" });
};

window.deleteStudent = async (id) => {
  if (!confirm("Delete this student?")) return;
  await fetch(`${API}/${id}`, { method: "DELETE" });
  showMessage("Student deleted");
  loadStudents();
};

$("cancelBtn").addEventListener("click", resetForm);
$("search").addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(loadStudents, 250);
});

loadStudents();
